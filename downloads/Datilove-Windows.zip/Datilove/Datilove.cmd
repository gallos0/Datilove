@echo off
rem Datilove - abre a versao sempre atualizada numa janela propria
start "" msedge --app=https://gallos0.github.io/Datilove/app/ --window-size=1320,880
if errorlevel 1 start "" https://gallos0.github.io/Datilove/app/
